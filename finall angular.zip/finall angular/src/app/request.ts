export class Request {
   loanRequestId:number;
    amount:number;
    type:string;
    tenure:number;
    roi:number;
    accountNumber:string;
}

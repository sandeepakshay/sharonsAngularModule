import { Ledger } from './ledger';

describe('Ledger', () => {
  it('should create an instance', () => {
    expect(new Ledger()).toBeTruthy();
  });
});
